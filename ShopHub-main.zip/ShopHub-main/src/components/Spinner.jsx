import React from 'react'

const Spinner = () => {
  return (
    <div>
      <div className='absolute custom-loader  top-[50%] left-[50%]'></div>
    </div>
  )
}

export default Spinner
